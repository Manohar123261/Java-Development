public class Arjun extends Pandav{
    
}