public class Vikarn extends Kaurav{
    public void fight(){
        System.out.println("vikarn is a nobel and good fighter");
    }
}