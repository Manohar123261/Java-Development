class Pandav extends Bharatvanshi {
    @Override
    public void fight() {
        System.out.println("Pandav fights with valor and skill.");
    }

    @Override
    public void obey() {
        System.out.println("Pandav obeys righteous commands.");
    }

    @Override
    public void kind() {
        System.out.println("Pandav shows kindness and compassion.");
    }
}
