abstract class Bharatvanshi {
    // Abstract methods
    public abstract void fight();
    public abstract void obey();
    public abstract void kind();
}