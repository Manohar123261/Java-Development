public abstract class Tea{
    public void boil();
    public void serve();
}