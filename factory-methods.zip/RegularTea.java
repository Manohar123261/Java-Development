public class RegularTea extends Tea{
    public void boil(){
        System.out.println("Boil for 3 min");
    }
    public void serve(){
        System.out.println("serve in kulladh");
    }
}