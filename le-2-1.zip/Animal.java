class Animal {
    public void makeVoice() {
        // Default voice for Animal class
        System.out.println("Animal sound");
    }
}