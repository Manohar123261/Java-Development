class Pig extends Animal {
    @Override
    public void makeVoice() {
        System.out.println("Pig says 'Oink'");
    }
}