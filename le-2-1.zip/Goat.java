class Goat extends Animal {
    @Override
    public void makeVoice() {
        System.out.println("Goat says 'Baa'");
    }
}