class Dog extends Animal {
    @Override
    public void makeVoice() {
        System.out.println("Dog says 'Woof'");
    }
}