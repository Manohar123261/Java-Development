class Cow extends Animal {
    @Override
    public void makeVoice() {
        System.out.println("Cow says 'Moo'");
    }
}