class Lion extends Animal {
    @Override
    public void makeVoice() {
        System.out.println("Lion says 'Roar'");
    }
}