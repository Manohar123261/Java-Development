public class B extends Beverage{
    protected void addCondiment(){
        System.out.println("add Ice");
    }
    protected boolean hook(){
        return false;
    }
}