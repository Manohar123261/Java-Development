public class W extends Beverage{
    protected void addCondiment(){
        System.out.println("add water");
    }
}