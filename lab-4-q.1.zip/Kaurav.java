class Kaurav extends Bharatvanshi {
    @Override
    public void fight() {
        System.out.println("Kaurav fights with aggression and cunningness.");
    }

    @Override
    public void obey() {
        System.out.println("Kaurav often disobeys and acts selfishly.");
    }

    @Override
    public void kind() {
        System.out.println("Kaurav lacks kindness and empathy.");
    }
}