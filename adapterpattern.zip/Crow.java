public interface Crow{
    void fly();
    void eat();
    void cry();
}