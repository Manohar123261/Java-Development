public interface Swan{
    void swim();
    void eat();
    void sing();
}