abstract class Decorator extends Offering{
    Offering offering;
}