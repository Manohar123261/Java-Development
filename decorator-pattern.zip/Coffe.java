class Coffee extends Offering{
    String getName(){
        return "Coffee ";
    }
    int getPrice(){
        return 35;
    }
}