public interface Testable{
    public void display();
}